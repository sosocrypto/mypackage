#mypackage
this package was created as an example on how to create my own package

#